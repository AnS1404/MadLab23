class One{
    One(int x){
        System.out.println(" Class One");
    }
}