class child extends mother{
    public static void show(){
        System.out.println("Hello JUET");
    }
}