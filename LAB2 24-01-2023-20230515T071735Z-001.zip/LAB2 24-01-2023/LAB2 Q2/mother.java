class mother{
    public static void show(){
        System.out.println("Hello World");
    }
    public static int x;
}