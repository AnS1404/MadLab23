class Child extends Mother{
    
}