public class Mother
{
    int x;
	public static void show() {
	   System.out.println("hello");
	}
}